import express from 'express';

const router = express.Router();

// Rota de exemplo
router.post('/', (req, res) => {
  const { name, nfNumbers, driverId, description } = req.body;

  if (!name || !nfNumbers || !driverId) {
    return res.status(400).json({ message: 'Campos obrigatórios faltando' });
  }

  // Lógica para salvar no banco (ex: Prisma ou outro ORM)
  console.log('Dados recebidos:', { name, nfNumbers, driverId, description });

  res.status(201).json({ message: 'Frete cadastrado com sucesso!' });
});

export default router;

