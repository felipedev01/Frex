import React from 'react';
import { View, Text } from 'react-native';

const HomeScreen = () => {
  return (
    <View>
      <Text>Bem-vindo ao App de Entregas!</Text>
    </View>
  );
};

export default HomeScreen;